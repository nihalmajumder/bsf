({
    doInit : function(component, event, helper){
        helper.doInit(component, event);
    },
    handleCancel: function(cmp, evt, helper) {
        helper.handleCancel(cmp, evt);
    },
    handleSave: function(cmp, evt, helper) {
        helper.handleSave(cmp, evt);
    },
    handleSearchValues : function(componet, event, helper){
        helper.handleSearchValues(componet, event);
    },
    handleAdd : function(component, event, helper){
        helper.handleAdd(component, event);
    },
    handleEdit : function(component, event, helper){
        helper.handleEdit(component, event);
    },
    handleOnSuccessCmpEvt : function(component, event, helper){
        helper.handleOnSuccessCmpEvt(component, event);
    }, 
    handleDelete : function(component, event, helper){
    	helper.handleDelete(component, event);
    },
    handleImport : function(component, event, helper){
        helper.handleImport(component, event);
    },
})