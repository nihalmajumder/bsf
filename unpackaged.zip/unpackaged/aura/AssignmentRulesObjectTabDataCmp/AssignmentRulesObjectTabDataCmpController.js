({
    handleClick : function(component, event, helper) {
        helper.handleClick(component, event);
    }
})