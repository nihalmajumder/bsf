({
	doInit : function(component, event, helper) {
		helper.doInit(component, event);
	},
    handleAppSelectEvt : function(component, event, helper){
        helper.handleAppSelectEvt(component, event);
    },
    handleQuit : function(component, event, helper){
        helper.handleQuit(component, event);
    },
    handlePrevious : function(component, event, helper){
        helper.handlePrevious(component, event);
    },
    handleRuleSelect : function(component, event, helper){
        helper.handleRuleSelect(component, event);
    }
})