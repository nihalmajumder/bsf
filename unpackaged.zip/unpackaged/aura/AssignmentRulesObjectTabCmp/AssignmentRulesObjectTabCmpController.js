({
    handleActive: function(component, event, helper) {
        helper.handleActive(component, event);
    },
})