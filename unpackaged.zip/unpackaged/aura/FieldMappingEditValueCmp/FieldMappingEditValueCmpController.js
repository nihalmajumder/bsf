({
    handleCancel: function(cmp, evt, helper) {
        helper.handleCancel(cmp, evt);
    },
    handleSave: function(cmp, evt, helper) {
        helper.handleSave(cmp, evt);
    }
})