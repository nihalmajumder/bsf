({
    doInit: function(component, event, helper){
        helper.doInit(component, event);
    },
    handleKeyUp : function(component, event, helper){
        helper.handleKeyUp(component, event, helper);
    },
    handleClick : function(component, event, helper){
        helper.handleClick(component, event);        
    },
    handleOnSuccessCmpEvt : function(component, event, helper){
        helper.handleOnSuccessCmpEvt(component, event);
    },
})