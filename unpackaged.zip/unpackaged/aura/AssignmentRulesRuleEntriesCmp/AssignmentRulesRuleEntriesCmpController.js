({
    handleOnObjectSelect : function(component, event, helper) {
        helper.handleOnObjectSelect(component, event);
    },
    handleNew : function(component, event, helper){
        helper.handleNew(component, event);
    },
    handleSuccess : function(component, event, helper){
        helper.handleOnObjectSelect(component, event);
    },
})