({
    handleCancel: function(cmp, evt, helper) {
        helper.handleCancel(cmp, evt);
    },
    handleDelete: function(cmp, evt, helper) {
        helper.handleDelete(cmp, evt);
    }
})