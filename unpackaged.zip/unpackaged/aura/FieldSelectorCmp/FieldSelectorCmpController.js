({
    handleChangeObject : function(component, event, helper) {
        helper.handleChangeObject(component, event);
    },
    handleFieldChange : function(component, event, helper){
        helper.handleFieldChange(component, event);
    },
    handleFieldSelect : function(component, event, helper){
        helper.handleFieldSelect(component, event);
    },
    handleCancel : function(component, event, helper){
        helper.handleCancel(component, event);
    },
})