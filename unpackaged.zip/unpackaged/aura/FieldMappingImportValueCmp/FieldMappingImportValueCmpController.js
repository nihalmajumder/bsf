({
     doInit : function(component, event, helper) {
        helper.doInit(component, event);
    },
    handleCancel : function(component, event, helper){
        helper.handleCancel(component, event);
    },
    handleImport : function(component, event, helper){
        helper.handleImport(component, event);
    },
    handleKeyUp : function(component, event, helper){
        helper.handleKeyUp(component, event);
    },
    handleCloseLookupList : function(component, event, helper){
        helper.handleCloseLookupList(component, event);
    },
    handleResultClick : function(component, event, helper){
        helper.handleResultClick(component, event);
    },
    handleClear : function(component, event, helper){
        helper.handleClear(component, event);
    },
})