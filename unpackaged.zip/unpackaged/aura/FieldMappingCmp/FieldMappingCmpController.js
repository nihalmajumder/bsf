({
    doInit : function(component, event, helper) {
        helper.doInit(component, event);
    },
    handleKeyUp : function(component, event, helper){
        helper.handleKeyUp(component, event);
    },
    handleNew : function(component, event, helper){
        helper.handleNew(component, event);
    },
    handleEdit : function(component, event, helper){
        helper.handleEdit(component, event);
    },
    handleDelete : function(component, event, helper){
        helper.handleDelete(component, event);
    },
    handleSuccesEvt : function(component, event, helper){
        helper.handleSuccess(component, event);
    },
})