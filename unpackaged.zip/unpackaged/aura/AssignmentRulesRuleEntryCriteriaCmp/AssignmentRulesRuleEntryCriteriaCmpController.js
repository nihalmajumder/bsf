({
    doInit : function(component, event, helper){
        helper.doInit(component, event);
    },
    handleSave : function(component, event, helper){
        helper.handleSave(component, event);
    },
    handleSuccess : function(component, event, helper){
        helper.doInit(component, event);
    },
    handleEvt: function(component, event, helper){
        helper.handleEvt(component, event);
    },
    handleFireEvt : function(component, event, helper){
        helper.handleFireEvt(component, event);
    },
})