({
    doInit : function(component, event, helper) {
        helper.doInit(component, event);
    },
    handleSave : function(component, event, helper) {
        helper.handleSave(component, event);
    },
    handleCancel : function(component, event, helper){
        helper.handleCancel(component, event);
    },
    handleLookupEvt : function(component, event, helper){
        helper.handleLookupEvt(component, event);
    }
})